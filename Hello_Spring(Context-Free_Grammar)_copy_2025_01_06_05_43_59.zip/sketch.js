let grammar;

function setup() {
  createCanvas(840, 194);
  textSize(20);
  textAlign(LEFT, TOP);

  // Define the grammar as an object
  grammar = {
    "start": [
      "Hello Spring.\nGoodbye Winter.\n<hello_attr><goodbye_attr><hello_activity><goodbye_activity>"
    ],
    "hello_attr": [
      "Hello <spring_attribute>.\n"
    ],
    "goodbye_attr": [
      "Goodbye <winter_attribute>.\n"
    ],
    "hello_activity": [
      "Hello <spring_activity>.\n"
    ],
    "goodbye_activity": [
      "Goodbye <winter_activity>.\n"
    ],
    "spring_attribute": [
      "warmth", "brightness", "grass", "sun", "flowers"
    ],
    "winter_attribute": [
      "cold", "snow", "cozyness", "darkness", "glühwein"
    ],
    "spring_activity": [
      "smelling flowers", "picnicking", "cycling", "sunbathing"
    ],
    "winter_activity": [
      "snowball fights", "ice-skating", "making a snowman", "sitting by a fire"
    ]
  };
}

function draw() {
  background(220);
  // Expand the <start> rule and display the result
  let generatedText = expand("start");
  text(generatedText, 10, 10, width - 20, height - 20); // Wrap text within canvas
  frameRate(0.2); // Generate new text every 5 seconds
}

// Expand grammar rules recursively
function expand(rule) {
  // If the rule exists in the grammar
  if (grammar[rule]) {
    // Choose a random option from the grammar rules
    let options = grammar[rule];
    let chosenOption = random(options);

    // Expand any placeholders recursively
    return chosenOption.replace(/<([^>]+)>/g, (match, subRule) => expand(subRule));
  }
  // If the rule is a terminal (e.g., "warmth"), return it directly
  return rule;
}
