let yaml;
let grammar;

function preload() {
  // Load the grammar file
  yaml = loadStrings('data/stochastic.txt');
}

function setup() {
  createCanvas(500, 200);
  textSize(16);
  textAlign(LEFT, TOP);

  // Join the YAML grammar and initialize it
  let grammarText = yaml.join('\n');
  try {
    grammar = RiGrammar(grammarText);
  } catch (error) {
    console.error("Grammar Error:", error);
    return;
  }
}

function draw() {
  background(220);

  if (grammar) {
    let generatedText = grammar.expandFrom('<poem>'); // Expand from <poem>
    text(generatedText, 10, 10, width - 20, height - 20); // Wrap the text
  } else {
    text("Error in loading grammar.", 10, 10);
  }

  frameRate(0.2); // Generate text every 5 seconds
}
