let json, animals;

function preload() {
  json = loadJSON('data/common.json');
}

function setup() {
  createCanvas(320, 80);
  animals = json.animals;
  // Sanity check: Print syllable count for all animal names loaded
  // for (let animal of animals) {
  //   print(animal + ": " + countSyllables(animal));
  // }
  textAlign(CENTER, CENTER);
}

function draw() {
  background(220);
  let lines = stanza();
  text(lines, width / 2, height / 2);
  frameRate(0.2);
}

function stanza() {
  let house = random(['Gryffindor', 'Ravenclaw', 'Hufflepuff', 'Slytherin']);

  // Choose animal1 with exactly 3 syllables
  let animal1 = random(animals.filter(animal => countSyllables(animal) === 3));

  // Choose animal2 with exactly 1 syllable
  let animal2 = random(animals.filter(animal => countSyllables(animal) === 1));

  // Get an adjective with 1 syllable that rhymes with animal2
  let adj = findRhymingAdjective(animal2);

  return "The body of " + a(animal1) +
    ", the wisdom of " + a(animal2) + "\n" +
    "I'm putting you in " + house +
    " for you are really " + adj;
}

// Finds a 1-syllable adjective that rhymes with the given word
function findRhymingAdjective(word) {
  let rhymes = RiTa.rhymes(word); // Get rhyming words
  let adjectives = rhymes.filter(rhyme => isAdjective(rhyme) && countSyllables(rhyme) === 1);

  if (adjectives.length > 0) {
    return random(adjectives); // Choose a random adjective if available
  } else {
    return "awesome"; // Default if no rhyming adjective found
  }
}

// List of words where RiTa gets the syllables wrong
const badcounts = [
  { "cougar": 2 },
  { "orangutan": 4 },
  { "reindeer": 2 }
];

// Counts syllables in a word
function countSyllables(word) {
  // Handle special cases in badcounts
  if (badcounts.some(obj => obj[word])) {
    return badcounts.find(obj => obj[word])[word];
  }
  // Replace hyphens with spaces
  const noHyphens = word.replaceAll("-", " ");
  // Get syllables string
  const syllables = RiTa.getSyllables(noHyphens);
  // Split syllables on "/" (syllables) and " " (words)
  return syllables.split(/[\/ ]/).length;
}

// Adds 'a' or 'an' before a word
function a(word) {
  let result = 'a';
  const noHyphens = word.replaceAll("-", " "); // Replace hyphens with spaces
  const firstPhoneme = RiTa.getPhonemes(noHyphens)[0];
  if (['a', 'e', 'i', 'o', 'u'].includes(firstPhoneme)) {
    result = 'an';
  }
  return result + ' ' + word;
}

// Checks if a word is an adjective
function isAdjective(word) {
  // Return true if word is tagged 'jj' (adjective)
  return RiTa.getPosTags(word)[0] === 'jj';
}
